package com.example.jaxssimpleapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind the views from the XML layout
        EditText nameText = findViewById(R.id.nameText);
        Button buttonSayHello = findViewById(R.id.buttonSayHello);
        TextView textGreeting = findViewById(R.id.textGreeting);

        // Set click listener to handle the greeting logic
        buttonSayHello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameText.getText().toString().trim();
                if (!name.isEmpty()) {
                    textGreeting.setText("Hello, " + name + "!");
                } else {
                    nameText.setError("Please enter your name");
                }
            }
        });
    }
}
package com.example.wetracfitapp.ui

import com.example.wetracfitapp.data.local.UserDao
import com.example.wetracfitapp.data.local.UserEntity
import com.example.wetracfitapp.app.data.local.GoalDao
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class UserRepositoryImpl @JvmOverloads constructor(
    private val userDao: UserDao,
    private val goalDao: GoalDao,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : UserRepository(userDao, goalDao) {

    override suspend fun verifyUserCredentials(username: String, passwordHash: String): UserEntity? {
        // Enforce thread execution shifts entirely off the main thread to standard IO threads
        return withContext(ioDispatcher) {
            userDao.verifyUserCredentials(username, passwordHash)
        }
    }
}
package com.example.wetracfitapp

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.wetracfitapp.app.data.local.GoalEntity
import com.example.wetracfitapp.app.data.local.UserProfile
import com.example.wetracfitapp.ui.FitnessDatabase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class UserSettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val sharedPrefs = context.getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
    private val goalDao = FitnessDatabase.getInstance(context).goalDao()
    private val profileDao = FitnessDatabase.getInstance(context).profileDao()

    // UI State backing fields
    private val _isMetric = MutableStateFlow(sharedPrefs.getBoolean("KEY_IS_METRIC", false))
    val isMetric: StateFlow<Boolean> = _isMetric.asStateFlow()

    private val _notificationsEnabled = MutableStateFlow(sharedPrefs.getBoolean("KEY_NOTIF_ENABLED", true))
    val notificationsEnabled: StateFlow<Boolean> = _notificationsEnabled.asStateFlow()

    private val _smsAlertsEnabled = MutableStateFlow(sharedPrefs.getBoolean("KEY_SMS_ALERTS_ENABLED", false))
    val smsAlertsEnabled: StateFlow<Boolean> = _smsAlertsEnabled.asStateFlow()

    private val _activePlan = MutableStateFlow(sharedPrefs.getString("KEY_ACTIVE_PLAN", "None (Free User)"))
    val activePlan: StateFlow<String?> = _activePlan.asStateFlow()

    private val _goalsList = MutableStateFlow<List<GoalEntity>>(emptyList())
    val goalsList: StateFlow<List<GoalEntity>> = _goalsList.asStateFlow()

    init {
        fetchGoals()
    }

    // Toggle Weight Units and Broadcast Change
    fun toggleWeightUnit(isMetricSelected: Boolean) {
        viewModelScope.launch {
            sharedPrefs.edit().putBoolean("KEY_IS_METRIC", isMetricSelected).apply()
            _isMetric.value = isMetricSelected

            // Broadcast intent to refresh other screens like Dashboard instantly
            val intent = Intent("com.example.app.ACTION_UNIT_CHANGED").apply {
                putExtra("IS_METRIC", isMetricSelected)
                setPackage(context.packageName)
            }
            context.sendBroadcast(intent)
        }
    }

    // Toggle Notifications
    fun toggleNotifications(isEnabled: Boolean) {
        viewModelScope.launch {
            sharedPrefs.edit().putBoolean("KEY_NOTIF_ENABLED", isEnabled).apply()
            _notificationsEnabled.value = isEnabled

            // Notification Manager logic can be triggered here or inside a WorkManager task
        }
    }

    // Toggle SMS Alerts
    fun toggleSmsAlerts(isEnabled: Boolean) {
        viewModelScope.launch {
            sharedPrefs.edit().putBoolean("KEY_SMS_ALERTS_ENABLED", isEnabled).apply()
            _smsAlertsEnabled.value = isEnabled
        }
    }

    // Fetch Badges and active rewards from Room Local DB
    private fun fetchGoals() {
        viewModelScope.launch {
            goalDao.getEarnedBadgesAndRewards().collect { goals ->
                _goalsList.value = goals
            }
        }
    }

    // Save Profile Modifications directly to Database
    fun updateProfile(profile: UserProfile, onComplete: () -> Unit) {
        viewModelScope.launch {
            profileDao.insertOrUpdateProfile(profile)
            onComplete()
        }
    }
}

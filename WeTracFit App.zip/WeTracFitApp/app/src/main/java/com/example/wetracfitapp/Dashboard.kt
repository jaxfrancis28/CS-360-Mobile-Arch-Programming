package com.example.wetracfitapp

import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.wetracfitapp.R
import com.example.wetracfitapp.UserProfile
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.card.MaterialCardView
import kotlin.random.Random

class Dashboard : AppCompatActivity() {

    private val fitnessTips = listOf(
        "Drink at least 8 glasses of water today!",
        "Take a 10-minute walk after your meal.",
        "Consistency is key. Keep showing up!",
        "Don't forget to stretch before and after your workout.",
        "A good night's sleep is as important as exercise.",
        "Eat more leafy greens for better energy levels.",
        "Try a new exercise today to keep things interesting.",
        "Focus on your breathing during high-intensity sets.",
        "Small progress is still progress. Don't give up!",
        "Listen to your body. Rest when you need to."
    )

    private val newsArticles = listOf(
        NewsArticle("New Study: HIIT Better for Fat Loss?", "Researchers find that high-intensity interval training may burn more calories than steady-state cardio."),
        NewsArticle("Top 5 Superfoods for Recovery", "Add these nutrition powerhouses to your diet to bounce back faster after intense gym sessions."),
        NewsArticle("The Importance of Mobility", "Why flexibility and joint health are the foundation of a long-term fitness routine."),
        NewsArticle("Yoga for Mental Clarity", "Beyond the physical benefits, yoga is proving to be a powerful tool for stress management.")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_dashboard)
        
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Handle Dashboard Toolbar navigation icon click (Back/Logout)
        findViewById<MaterialToolbar>(R.id.dashboardToolbar).setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        // Navigate to Profile screen when the logo is clicked
        findViewById<ImageView>(R.id.imgDashboardLogo).setOnClickListener {
            val intent = Intent(this, UserProfile::class.java)
            startActivity(intent)
        }

        // Display a random fitness tip
        val txtFitnessTips = findViewById<TextView>(R.id.txtFitnessTips)
        showRandomTip(txtFitnessTips)

        // Allow users to tap the card to get a new tip
        findViewById<MaterialCardView>(R.id.cardInsights).setOnClickListener {
            showRandomTip(txtFitnessTips)
        }

        // Navigate to Inventory screen
        findViewById<MaterialCardView>(R.id.cardInventory).setOnClickListener {
            val intent = Intent(this, InventoryActivity::class.java)
            startActivity(intent)
        }

        // Navigate to Premium Plans screen
        findViewById<MaterialCardView>(R.id.cardPremium).setOnClickListener {
            val intent = Intent(this, SubscriptionActivity::class.java)
            startActivity(intent)
        }

        // Set up Fitness News RecyclerView
        setupNewsRecyclerView()

        // Check if we should show the exciting badge notification
        val showOverlay = intent.getBooleanExtra("SHOW_BADGE_OVERLAY", false)
        if (showOverlay) {
            showExcitingBadgeDialog()
        }
    }

    private fun showExcitingBadgeDialog() {
        val dialog = Dialog(this, android.R.style.Theme_Material_Light_NoActionBar_Fullscreen)
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_badge_exciting, null)
        dialog.setContentView(dialogView)
        dialog.setCancelable(false)

        dialogView.findViewById<Button>(R.id.btnContinue).setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun showRandomTip(textView: TextView) {
        val randomIndex = Random.nextInt(fitnessTips.size)
        textView.text = fitnessTips[randomIndex]
    }

    private fun setupNewsRecyclerView() {
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerNews)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = NewsAdapter(newsArticles)
    }

    // Data class for News
    data class NewsArticle(val title: String, val description: String)

    // Simple Adapter for News
    private class NewsAdapter(private val articles: List<NewsArticle>) :
        RecyclerView.Adapter<NewsAdapter.ViewHolder>() {

        class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val title: TextView = view.findViewById(R.id.txtNewsTitle)
            val description: TextView = view.findViewById(R.id.txtNewsDescription)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_news, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val article = articles[position]
            holder.title.text = article.title
            holder.description.text = article.description
        }

        override fun getItemCount() = articles.size
    }
}
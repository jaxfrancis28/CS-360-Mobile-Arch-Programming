// WeightViewModel.kt
package com.example.wetracfitapp.ui

import androidx.lifecycle.*
import com.example.wetracfitapp.data.WeightEntry
import com.example.wetracfitapp.data.WeightDao
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar

class WeightViewModel(private val weightDao: WeightDao) : ViewModel() {

    private val _selectedInterval = MutableStateFlow(Interval.WEEK)
    val selectedInterval: StateFlow<Interval> = _selectedInterval

    // Automatically switches the query based on the active interval tab
    val weightHistory: LiveData<List<WeightEntry>> = _selectedInterval
        .flatMapLatest { interval ->
            weightDao.getWeightEntriesSince(getStartTimeForInterval(interval))
        }
        .asLiveData()

    // Computes rolling average from the current filtered list
    val rollingAverage: LiveData<Double> = weightHistory.map { entries ->
        if (entries.isEmpty()) 0.0 else entries.map { it.weight }.average()
    }

    // Dynamic fitness tips based on weight trend shifts
    val fitnessTip: LiveData<String> = rollingAverage.map { avg ->
        when {
            avg == 0.0 -> "Log your first weight entry to receive smart fitness insights!"
            avg > 90.0 -> "Focus on steady cardio and a sustainable caloric deficit this week."
            else -> "Great consistency! Keep balancing your protein intake with resistance training."
        }
    }

    fun setInterval(interval: Interval) {
        _selectedInterval.value = interval
    }

    fun addWeightEntry(weight: Double) {
        viewModelScope.launch {
            weightDao.insertWeight(WeightEntry(weight = weight, timestamp = System.currentTimeMillis()))
        }
    }

    private fun getStartTimeForInterval(interval: Interval): Long {
        val cal = Calendar.getInstance()
        when (interval) {
            Interval.DAY -> cal.add(Calendar.DAY_OF_YEAR, -1)
            Interval.WEEK -> cal.add(Calendar.WEEK_OF_YEAR, -1)
            Interval.MONTH -> cal.add(Calendar.MONTH, -1)
            Interval.YEAR -> cal.add(Calendar.YEAR, -1)
        }
        return cal.timeInMillis
    }

    enum class Interval { DAY, WEEK, MONTH, YEAR }
}
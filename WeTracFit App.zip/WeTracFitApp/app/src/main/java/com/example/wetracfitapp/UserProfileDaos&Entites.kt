package com.example.wetracfitapp.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Dao
import androidx.room.Query
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "goals_table")
data class GoalEntity(
    @PrimaryKey val id: Int,
    val title: String,
    val isBadge: Boolean,         // True if badge, false if reward
    val imageUrl: String,
    val dateUnlocked: Long
)

@Entity(tableName = "user_profiles")
data class UserProfile(
    @PrimaryKey val username: String,
    val fullName: String,
    val age: Int,
    val weight: Double,
    val height: Double
)

@Dao
interface GoalDao {
    @Query("SELECT * FROM goals_table ORDER BY dateUnlocked DESC")
    fun getEarnedBadgesAndRewards(): Flow<List<GoalEntity>>

    @Query("SELECT COUNT(*) FROM goals_table WHERE title = :title")
    suspend fun hasBadge(title: String): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertGoal(goal: GoalEntity)

    @Query("UPDATE goals_table SET imageUrl = :newImageUrl WHERE title = :title")
    suspend fun updateBadgeImage(title: String, newImageUrl: String)
}

@Dao
interface ProfileDao {
    @Query("SELECT * FROM user_profiles WHERE username = :username LIMIT 1")
    fun getProfile(username: String): Flow<UserProfile?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateProfile(profile: UserProfile)
}

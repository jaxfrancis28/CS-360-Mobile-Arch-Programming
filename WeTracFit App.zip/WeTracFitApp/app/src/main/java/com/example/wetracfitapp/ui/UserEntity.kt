package com.example.wetracfitapp.ui// Duplicate file, can be safely deleted.

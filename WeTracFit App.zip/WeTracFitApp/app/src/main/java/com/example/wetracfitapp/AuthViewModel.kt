package com.example.wetracfitapp.ui.auth

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.wetracfitapp.ui.UserRepository
import kotlinx.coroutines.launch

class AuthViewModel(private val userRepository: UserRepository) : ViewModel() {

    // Sealed class to represent the different UI navigation states
    sealed class AuthNavigationState {
        object Loading: AuthNavigationState()
        data class GoToDashboard(val isFirstLogin: Boolean = false): AuthNavigationState()
        object GoToOnboarding: AuthNavigationState()
        data class Error(val message: String) : AuthNavigationState()
    }

    private val _navigationState = MutableLiveData<AuthNavigationState>()
    val navigationState: LiveData<AuthNavigationState> = _navigationState

    fun validateCredentials(username: String, passwordHash: String) {
        if (username.isBlank() || passwordHash.isBlank()) {
            _navigationState.value = AuthNavigationState.Error("Fields cannot be empty")
            return
        }

        _navigationState.value = AuthNavigationState.Loading

        // Run asynchronous database check using the viewModelScope
        viewModelScope.launch {
            try {
                // Run asynchronous database check using the viewModelScope
                viewModelScope.launch {
                    try {
                        val user = userRepository.verifyUserCredentials(username, passwordHash)
                        if (user != null || (username == "user@example.com" && passwordHash == "ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f")) {
                            val isFirst = userRepository.awardFirstLoginBadge()
                            _navigationState.value = AuthNavigationState.GoToDashboard(isFirst)
                        } else {
                            _navigationState.value = AuthNavigationState.Error("Invalid username or password")
                        }
                    } catch (e: Exception) {
                        _navigationState.value = AuthNavigationState.Error("Database connection failed")
                    }
                }
            } catch (e: Exception) {
                _navigationState.value = AuthNavigationState.Error("Database connection failed")
            }
        }
    }
}
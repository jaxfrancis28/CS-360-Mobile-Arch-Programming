
package com.example.wetracfitapp.ui;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.example.wetracfitapp.data.WeightDao;
import com.example.wetracfitapp.data.WeightEntry;
import com.example.wetracfitapp.data.InventoryDao;
import com.example.wetracfitapp.data.model.InventoryItem;
import com.example.wetracfitapp.data.local.UserDao;
import com.example.wetracfitapp.data.local.UserEntity;
import com.example.wetracfitapp.app.data.local.GoalEntity;
import com.example.wetracfitapp.app.data.local.GoalDao;
import com.example.wetracfitapp.app.data.local.UserProfile;
import com.example.wetracfitapp.app.data.local.ProfileDao;

import java.util.concurrent.Executors;

// Declaring the entities (tables) in the database and current schema version
@Database(entities = {UserEntity.class, WeightEntry.class, GoalEntity.class, UserProfile.class, InventoryItem.class}, version = 6, exportSchema = false)
public abstract class FitnessDatabase extends RoomDatabase {

    // Define the abstract getter methods for your DAOs
    public abstract UserDao userDao();
    public abstract WeightDao weightDao();
    public abstract GoalDao goalDao();
    public abstract ProfileDao profileDao();
    public abstract InventoryDao inventoryDao();

    // Volatile instance guarantees that changes made by one thread are visible to all threads instantly
    private static volatile FitnessDatabase INSTANCE;

    /**
     * Singleton instance provider.
     * Uses double-checked locking to guarantee safety across multiple asynchronous threads.
     */
    public static FitnessDatabase getInstance(final Context context) {
        if (INSTANCE == null) {
            synchronized (FitnessDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    FitnessDatabase.class,
                                    "fitness_app_database"
                            )
                            // Optional: Clears database entirely if the schema version changes without a defined migration path
                            .fallbackToDestructiveMigration()
                            .addCallback(new RoomDatabase.Callback() {
                                @Override
                                public void onCreate(@NonNull SupportSQLiteDatabase db) {
                                    super.onCreate(db);
                                    // Pre-populate database with a test user
                                    Executors.newSingleThreadExecutor().execute(() -> {
                                        // user@example.com / password123
                                        UserEntity testUser = new UserEntity(
                                                "user@example.com",
                                                "ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f",
                                                true,
                                                System.currentTimeMillis()
                                        );
                                        getInstance(context).userDao().insertUserSync(testUser);
                                    });
                                }
                            })
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}

package com.example.wetracfitapp.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val username: String,
    val passwordHash: String,
    val isOnboardingComplete: Boolean,
    val createdAt: Long = System.currentTimeMillis()
)
package com.example.wetracfitapp

import android.app.Application
import android.content.Context
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import android.Manifest
import android.content.pm.PackageManager
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.wetracfitapp.data.InventoryDao
import com.example.wetracfitapp.data.model.InventoryItem
import com.example.wetracfitapp.ui.FitnessDatabase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class InventoryViewModel(application: Application) : AndroidViewModel(application) {
    
    private val TAG = "InventoryViewModel"

    private val inventoryDao: InventoryDao = FitnessDatabase.getInstance(application).inventoryDao()
    private val sharedPrefs = application.getSharedPreferences("user_prefs", Context.MODE_PRIVATE)

    private val _items = MutableStateFlow<List<InventoryItem>>(emptyList())
    val items: StateFlow<List<InventoryItem>> = _items.asStateFlow()

    init {
        viewModelScope.launch {
            inventoryDao.getAllItems().collect {
                _items.value = it
            }
        }
    }

    fun addItem(name: String, value: Int) {
        viewModelScope.launch {
            val newItem = InventoryItem(name = name, value = value)
            inventoryDao.insertItem(newItem)
            checkLowInventory(newItem)
        }
    }

    fun updateItem(item: InventoryItem) {
        viewModelScope.launch {
            inventoryDao.updateItem(item)
            checkLowInventory(item)
        }
    }

    fun deleteItem(item: InventoryItem) {
        viewModelScope.launch {
            inventoryDao.deleteItem(item)
        }
    }

    private fun checkLowInventory(item: InventoryItem) {
        val smsEnabled = sharedPrefs.getBoolean("KEY_SMS_ALERTS_ENABLED", false)
        if (smsEnabled && item.value < 3) {
            sendSmsAlert("Low Inventory Alert: ${item.name} is down to ${item.value} units!")
        }
    }

    private fun sendSmsAlert(message: String) {
        if (ContextCompat.checkSelfPermission(getApplication(), Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                Log.d(TAG, "Sending SMS alert: $message")
                val smsManager: SmsManager = getApplication<Application>().getSystemService(SmsManager::class.java)
                // Sending to a dummy number for testing
                smsManager.sendTextMessage("5551234", null, message, null, null)
            } catch (e: Exception) {
                Log.e(TAG, "Error sending SMS", e)
            }
        } else {
            Log.w(TAG, "SMS permission not granted, skipping alert.")
        }
    }
}

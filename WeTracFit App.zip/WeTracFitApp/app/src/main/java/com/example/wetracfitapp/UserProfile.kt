package com.example.wetracfitapp

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import android.widget.ImageView
import android.widget.TextView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.wetracfitapp.app.data.local.GoalEntity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.materialswitch.MaterialSwitch
import kotlinx.coroutines.launch

class UserProfile : AppCompatActivity() {

    private val viewModel: UserSettingsViewModel by viewModels()
    private lateinit var goalsAdapter: GoalsAdapter

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            viewModel.toggleSmsAlerts(true)
            Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show()
        } else {
            viewModel.toggleSmsAlerts(false)
            findViewById<MaterialSwitch>(R.id.switchSmsAlerts).isChecked = false
            Toast.makeText(this, "SMS Permission Denied. Feature disabled.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_user_profile)
        
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        setupToolbar()
        setupSwitches()
        setupGoalsRecyclerView()
        setupButtons()
    }

    private fun setupGoalsRecyclerView() {
        val rvGoals = findViewById<RecyclerView>(R.id.rvGoals)
        goalsAdapter = GoalsAdapter()
        rvGoals.layoutManager = LinearLayoutManager(this)
        rvGoals.adapter = goalsAdapter

        lifecycleScope.launch {
            viewModel.goalsList.collect { goals ->
                goalsAdapter.setGoals(goals)
            }
        }
    }

    private class GoalsAdapter : RecyclerView.Adapter<GoalsAdapter.ViewHolder>() {
        private var goals: List<GoalEntity> = emptyList()

        fun setGoals(newGoals: List<GoalEntity>) {
            goals = newGoals
            notifyDataSetChanged()
        }

        class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val icon: ImageView = view.findViewById(R.id.ivGoalTypeIcon)
            val title: TextView = view.findViewById(R.id.tvGoalTitle)
            val type: TextView = view.findViewById(R.id.tvGoalTypeLabel)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.recyclerview, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val goal = goals[position]
            holder.title.text = goal.title
            holder.type.text = if (goal.isBadge) "Badge" else "Active Reward"
            
            // Map imageUrl to drawable resource
            val resourceId = holder.itemView.context.resources.getIdentifier(
                goal.imageUrl, "drawable", holder.itemView.context.packageName
            )
            if (resourceId != 0) {
                holder.icon.setImageResource(resourceId)
            }
        }

        override fun getItemCount() = goals.size
    }

    private fun setupToolbar() {
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
    }

    private fun setupSwitches() {
        val switchWeight = findViewById<MaterialSwitch>(R.id.switchWeightUnit)
        val switchNotifications = findViewById<MaterialSwitch>(R.id.switchReminders)
        val switchSms = findViewById<MaterialSwitch>(R.id.switchSmsAlerts)
        val tvActivePlan = findViewById<TextView>(R.id.tvActiveSubscription)

        lifecycleScope.launch {
            viewModel.isMetric.collect { switchWeight.isChecked = it }
        }
        lifecycleScope.launch {
            viewModel.notificationsEnabled.collect { switchNotifications.isChecked = it }
        }
        lifecycleScope.launch {
            viewModel.smsAlertsEnabled.collect { switchSms.isChecked = it }
        }
        lifecycleScope.launch {
            viewModel.activePlan.collect { tvActivePlan.text = it }
        }

        switchWeight.setOnCheckedChangeListener { _, isChecked ->
            viewModel.toggleWeightUnit(isChecked)
        }

        switchNotifications.setOnCheckedChangeListener { _, isChecked ->
            viewModel.toggleNotifications(isChecked)
        }

        switchSms.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                checkSmsPermission()
            } else {
                viewModel.toggleSmsAlerts(false)
            }
        }
    }

    private fun setupButtons() {
        findViewById<Button>(R.id.btnUpdateProfile).setOnClickListener {
            val intent = Intent(this, InventoryActivity::class.java)
            startActivity(intent)
        }
    }

    private fun checkSmsPermission() {
        when {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
            ) == PackageManager.PERMISSION_GRANTED -> {
                viewModel.toggleSmsAlerts(true)
            }
            shouldShowRequestPermissionRationale(Manifest.permission.SEND_SMS) -> {
                Toast.makeText(this, "SMS permission is required for alerts.", Toast.LENGTH_LONG).show()
                requestPermissionLauncher.launch(Manifest.permission.SEND_SMS)
            }
            else -> {
                requestPermissionLauncher.launch(Manifest.permission.SEND_SMS)
            }
        }
    }
}

package com.example.wetracfitapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.wetracfitapp.data.model.InventoryItem
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class InventoryActivity : AppCompatActivity() {

    private val viewModel: InventoryViewModel by viewModels()
    private lateinit var adapter: InventoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_inventory)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        setupRecyclerView()
        setupListeners()
        observeViewModel()
    }

    private fun setupRecyclerView() {
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerInventory)
        recyclerView.layoutManager = GridLayoutManager(this, 2)
        adapter = InventoryAdapter(
            onItemClick = { showUpdateDialog(it) },
            onItemLongClick = { showDeleteConfirmation(it) }
        )
        recyclerView.adapter = adapter
    }

    private fun setupListeners() {
        findViewById<MaterialToolbar>(R.id.toolbar).setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        findViewById<FloatingActionButton>(R.id.fabAddItem).setOnClickListener {
            showAddDialog()
        }

        findViewById<View>(R.id.btnSendSms).setOnClickListener {
            sendSmsSummary()
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.items.collect {
                adapter.submitList(it)
            }
        }
    }

    private fun showAddDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_inventory_item, null)
        val etName = dialogView.findViewById<EditText>(R.id.etItemName)
        val etValue = dialogView.findViewById<EditText>(R.id.etItemValue)

        AlertDialog.Builder(this)
            .setTitle("Add Inventory Item")
            .setView(dialogView)
            .setPositiveButton("Add") { _, _ ->
                val name = etName.text.toString()
                val value = etValue.text.toString().toIntOrNull() ?: 0
                if (name.isNotEmpty()) {
                    viewModel.addItem(name, value)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showUpdateDialog(item: InventoryItem) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_inventory_item, null)
        val etName = dialogView.findViewById<EditText>(R.id.etItemName)
        val etValue = dialogView.findViewById<EditText>(R.id.etItemValue)

        etName.setText(item.name)
        etValue.setText(item.value.toString())

        AlertDialog.Builder(this)
            .setTitle("Update Item")
            .setView(dialogView)
            .setPositiveButton("Update") { _, _ ->
                val name = etName.text.toString()
                val value = etValue.text.toString().toIntOrNull() ?: item.value
                if (name.isNotEmpty()) {
                    viewModel.updateItem(item.copy(name = name, value = value, date = System.currentTimeMillis()))
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showDeleteConfirmation(item: InventoryItem) {
        AlertDialog.Builder(this)
            .setTitle("Delete Item")
            .setMessage("Are you sure you want to delete ${item.name}?")
            .setPositiveButton("Delete") { _, _ ->
                viewModel.deleteItem(item)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun sendSmsSummary() {
        val items = viewModel.items.value
        if (items.isEmpty()) {
            Toast.makeText(this, "Inventory is empty", Toast.LENGTH_SHORT).show()
            return
        }

        val summary = items.joinToString("\n") { "${it.name}: ${it.value}" }
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:")
            putExtra("sms_body", "Inventory Summary:\n$summary")
        }
        startActivity(intent)
    }

    private class InventoryAdapter(
        private val onItemClick: (InventoryItem) -> Unit,
        private val onItemLongClick: (InventoryItem) -> Unit
    ) : RecyclerView.Adapter<InventoryAdapter.ViewHolder>() {

        private var items: List<InventoryItem> = emptyList()

        fun submitList(newItems: List<InventoryItem>) {
            items = newItems
            notifyDataSetChanged()
        }

        class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val txtName: TextView = view.findViewById(R.id.txtItemName)
            val txtValue: TextView = view.findViewById(R.id.txtItemValue)
            val txtDate: TextView = view.findViewById(R.id.txtItemDate)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_inventory, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = items[position]
            holder.txtName.text = item.name
            holder.txtValue.text = "Value: ${item.value}"
            
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
            holder.txtDate.text = "Updated: ${sdf.format(Date(item.date))}"

            holder.itemView.setOnClickListener { onItemClick(item) }
            holder.itemView.setOnLongClickListener {
                onItemLongClick(item)
                true
            }
        }

        override fun getItemCount() = items.size
    }
}

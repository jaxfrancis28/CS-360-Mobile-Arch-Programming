// WeightDao.kt
package com.example.wetracfitapp.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface WeightDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeight(entry: WeightEntry)

    @Query("SELECT * FROM weight_entries ORDER BY timestamp DESC")
    fun getAllWeightEntries(): Flow<List<WeightEntry>>

    @Query("SELECT * FROM weight_entries WHERE timestamp >= :startTime ORDER BY timestamp ASC")
    fun getWeightEntriesSince(startTime: Long): Flow<List<WeightEntry>>

    @Delete
    suspend fun deleteWeight(entry: WeightEntry)
}
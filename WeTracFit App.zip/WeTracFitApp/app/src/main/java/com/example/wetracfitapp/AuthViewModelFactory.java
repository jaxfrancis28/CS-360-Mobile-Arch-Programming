package com.example.wetracfitapp;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.example.wetracfitapp.ui.UserRepository;
import com.example.wetracfitapp.ui.auth.AuthViewModel;

public class AuthViewModelFactory implements ViewModelProvider.Factory {

    private final UserRepository userRepository;

    /**
     * Constructor to inject the required data layer repository interface.
     */
    public AuthViewModelFactory(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @NonNull
    @Override
    @SuppressWarnings("unchecked")
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        // Verify that the requested ViewModel class matches our AuthViewModel or assignable subclasses
        if (modelClass.isAssignableFrom(AuthViewModel.class)) {
            return (T) new AuthViewModel(userRepository);
        }
        throw new IllegalArgumentException("Unknown ViewModel class dependency requested: " + modelClass.getName());
    }
}
package com.example.wetracfitapp.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryRed = Color(0xFFD32F2F)
val SecondaryGreen = Color(0xFF388E3C)
val TertiaryBlue = Color(0xFF1976D2)

val PrimaryRedDark = Color(0xFF9A0007)
val SecondaryGreenDark = Color(0xFF00600F)
val TertiaryBlueDark = Color(0xFF004BA0)

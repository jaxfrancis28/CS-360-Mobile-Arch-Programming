package com.example.wetracfitapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.wetracfitapp.ui.UserRepositoryImpl;
import com.example.wetracfitapp.ui.FitnessDatabase;
import com.example.wetracfitapp.ui.auth.AuthViewModel;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public class MainActivity extends AppCompatActivity {

    private AuthViewModel authViewModel;
    private ProgressBar progressBar;
    private Button btnSignIn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize Architecture Components manually for Java standard framework
        initializeViewModel();

        // Bind XML Views
        EditText etUsername = findViewById(R.id.username);
        EditText etPassword = findViewById(R.id.password);
        btnSignIn = findViewById(R.id.login);
        // TextView tvSignUp = findViewById(R.id.tvSignUp);
        progressBar = findViewById(R.id.loading);

        // Observe ViewModel live data states for decoupled architecture response
        authViewModel.getNavigationState().observe(this, this::handleNavigationState);

        // Handle Click Event for Sign In
        btnSignIn.setOnClickListener(v -> {
            String username = etUsername.getText().toString().trim();
            String plainPassword = etPassword.getText().toString().trim();

            // Hash the password securely before passing it out of UI controller context
            String hashedPassword = hashPasswordSHA256(plainPassword);

            authViewModel.validateCredentials(username, hashedPassword);
        });

        // Handle Click Event for New User Route
        // tvSignUp.setOnClickListener(v -> navigateToOnboarding());
    }

    /**
     * Initializes the Room Dao, Repository implementation, and provides the dependency inject lifecycle
     */
    private void initializeViewModel() {
        FitnessDatabase db = FitnessDatabase.getInstance(getApplicationContext());
        UserRepositoryImpl repository = new UserRepositoryImpl(db.userDao(), db.goalDao());
        AuthViewModelFactory factory = new AuthViewModelFactory(repository);

        authViewModel = new ViewModelProvider(this, factory).get(AuthViewModel.class);
    }

    /**
     * Updates UI components and handles Navigation Intent flow based on state emitted by ViewModel
     */
    private void handleNavigationState(AuthViewModel.AuthNavigationState state) {
        // Reset defaults
        progressBar.setVisibility(View.GONE);
        btnSignIn.setEnabled(true);

        if (state instanceof AuthViewModel.AuthNavigationState.Loading) {
            progressBar.setVisibility(View.VISIBLE);
            btnSignIn.setEnabled(false);

        } else if (state instanceof AuthViewModel.AuthNavigationState.GoToDashboard) {
            boolean isFirst = ((AuthViewModel.AuthNavigationState.GoToDashboard) state).isFirstLogin();
            Intent intent = new Intent(this, Dashboard.class);
            intent.putExtra("SHOW_BADGE_OVERLAY", isFirst);
            startActivity(intent);
            finish(); // Destroys context stack prevents user from backing into login

        } else if (state instanceof AuthViewModel.AuthNavigationState.GoToOnboarding) {
            navigateToOnboarding();

        } else if (state instanceof AuthViewModel.AuthNavigationState.Error) {
            String errorMessage = ((AuthViewModel.AuthNavigationState.Error) state).getMessage();
            Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show();
        }
    }

    private void navigateToOnboarding() {
        // Intent intent = new Intent(this, OnboardingActivity.class);
        // startActivity(intent);
        // finish();
        Toast.makeText(this, "Onboarding not implemented", Toast.LENGTH_SHORT).show();
    }

    /**
     * Core Java implementation utility function to cleanly hash the incoming user secret
     */
    private String hashPasswordSHA256(String password) {
        if (password.isEmpty()) return "";
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b: hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            return "";
        }
    }
}

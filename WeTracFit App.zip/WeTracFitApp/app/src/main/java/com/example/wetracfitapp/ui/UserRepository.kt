package com.example.wetracfitapp.ui

import com.example.wetracfitapp.data.local.UserDao
import com.example.wetracfitapp.data.local.UserEntity
import com.example.wetracfitapp.app.data.local.GoalDao
import com.example.wetracfitapp.app.data.local.GoalEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// Repository with explicit I/O safety thread dispatching
open class UserRepository(
    private val userDao: UserDao,
    private val goalDao: GoalDao
) {
    open suspend fun verifyUserCredentials(username: String, passwordHash: String): UserEntity? {
        return withContext(Dispatchers.IO) {
            userDao.verifyUserCredentials(username, passwordHash)
        }
    }

    open suspend fun awardFirstLoginBadge(): Boolean {
        return withContext(Dispatchers.IO) {
            val title = "Let the Fitness Begin"
            val image = "ic_let_the_finess_begin_badge"
            if (goalDao.hasBadge(title) == 0) {
                val badge = GoalEntity(
                    id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt(),
                    title = title,
                    isBadge = true,
                    imageUrl = image,
                    dateUnlocked = System.currentTimeMillis()
                )
                goalDao.insertGoal(badge)
                true
            } else {
                // Update the image if the badge already exists
                goalDao.updateBadgeImage(title, image)
                false
            }
        }
    }
}

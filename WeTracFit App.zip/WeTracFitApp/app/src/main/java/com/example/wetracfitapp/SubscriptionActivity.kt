package com.example.wetracfitapp

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.appbar.MaterialToolbar

class SubscriptionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_subscription)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        findViewById<MaterialToolbar>(R.id.subscriptionToolbar).setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        findViewById<Button>(R.id.btnSelectMealPrep).setOnClickListener {
            savePlanAndExit("Meal Prep Master")
        }

        findViewById<Button>(R.id.btnSelectCoaching).setOnClickListener {
            savePlanAndExit("Live Elite Coaching")
        }
    }

    private fun savePlanAndExit(planName: String) {
        val sharedPrefs = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        sharedPrefs.edit().putString("KEY_ACTIVE_PLAN", planName).apply()

        AlertDialog.Builder(this)
            .setTitle("Welcome to Premium!")
            .setMessage("You have successfully subscribed to the $planName plan.")
            .setPositiveButton("Awesome") { _, _ -> finish() }
            .setCancelable(false)
            .show()
    }
}
